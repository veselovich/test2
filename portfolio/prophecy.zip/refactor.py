import csv
from cs50 import SQL

students = []
houses = []
with open("students.csv") as file:
    file_reader = csv.DictReader(file)
    for row in file_reader:
        students.append(row)
        dict = {'house': row['house'], 'head': row['head']}
        if dict not in houses:
            houses.append(dic)

i = 1
for house in houses:
    house["id"] = "{}".format(i)
    i += 1

file2 = open("roster2.db", "w")
file2.close()

db = SQL("sqlite:///roster2.db")
db.execute("""
CREATE TABLE students (
    id INTEGER,
    student_name TEXT,
    PRIMARY KEY(id)
);""")
db.execute(
"""CREATE TABLE houses (
    id INTEGER,
    house TEXT,
    head TEXT,
    PRIMARY KEY(id)
);""")
db.execute("""
CREATE TABLE assignments (
    id INTEGER,
    student_id INTEGER,
    house_id INTEGER,
    FOREIGN KEY(student_id) REFERENCES students(id),
    FOREIGN KEY(house_id) REFERENCES houses(id)
);""")

for j in range(len(houses)):
    db.execute("INSERT INTO houses (id, house, head) VALUES (?, ?, ?)", (j+1), houses[j]["house"], houses[j]["head"])

for i in range(len(students)):
    db.execute("INSERT INTO students (id, student_name) VALUES (?, ?)", (i+1), students[i]["student_name"])
    for house in houses:
        if students[i]["house"] in house.values():
            db.execute("INSERT INTO assignments (id, student_id, house_id) VALUES (?, ?, ?)", (i+1), students[i]["id"], house["id"])

